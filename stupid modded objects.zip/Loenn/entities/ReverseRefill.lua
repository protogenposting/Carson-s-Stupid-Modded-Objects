local ReverseRefill = {}

ReverseRefill.name = "stupid_modded_objects/ReverseRefill"
ReverseRefill.texture = "objects/BumperIdle/22"
ReverseRefill.placements = {
    name = "Reverse Refill",
	data = {}
}
return ReverseRefill