local CoffeeRefill = {}

CoffeeRefill.name = "stupid_modded_objects/CoffeeRefill"
CoffeeRefill.texture = "objects/BumperIdle/22"
CoffeeRefill.placements = {
    name = "Coffee Refill",
	data = {}
}
return CoffeeRefill