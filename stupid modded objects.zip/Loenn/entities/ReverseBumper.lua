local ReverseBumper = {}

ReverseBumper.name = "stupid_modded_objects/ReverseBumper"
ReverseBumper.texture = "objects/BumperIdle/22"
ReverseBumper.placements = {
    name = "Reverse Bumper",
	data = {}
}
return ReverseBumper