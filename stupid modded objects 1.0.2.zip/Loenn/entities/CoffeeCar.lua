local CoffeeCar = {}

CoffeeCar.name = "stupid_modded_objects/CoffeeCar"
CoffeeCar.texture = "scenery/car/body"
CoffeeCar.placements = {
    name = "Coffee Car",
	data = {}
}
return CoffeeCar